// Authentication handling for Pet Adoption System

// User storage key
const USERS_STORAGE_KEY = 'petAdoptionUsers';

// Get all users from storage
function getUsers() {
    const users = localStorage.getItem(USERS_STORAGE_KEY);
    return users ? JSON.parse(users) : [];
}

// Save users to storage
function saveUsers(users) {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
}

// Find user by email
function findUserByEmail(email) {
    const users = getUsers();
    return users.find(u => u.email.toLowerCase() === email.toLowerCase());
}

// Register new user
function registerUser(name, email, password) {
    const users = getUsers();

    // Check if email already exists
    if (findUserByEmail(email)) {
        return { success: false, message: 'Email already registered' };
    }

    // Create new user
    const newUser = {
        id: Date.now(),
        name: name.trim(),
        email: email.toLowerCase().trim(),
        password: password,
        createdAt: new Date().toISOString()
    };

    users.push(newUser);
    saveUsers(users);

    return { success: true, user: newUser };
}

// Login user
function loginUser(email, password) {
    const user = findUserByEmail(email);

    if (!user) {
        return { success: false, message: 'User not found' };
    }

    if (user.password !== password) {
        return { success: false, message: 'Incorrect password' };
    }

    // Store current user session (without password)
    const sessionUser = { ...user };
    delete sessionUser.password;
    localStorage.setItem('currentUser', JSON.stringify(sessionUser));

    return { success: true, user: sessionUser };
}

// Form validation helpers
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePassword(password) {
    return password.length >= 6;
}

function validateName(name) {
    return name.trim().length >= 2;
}

// Setup login form
function setupLoginForm() {
    const form = document.getElementById('login-form');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        // Clear previous errors
        clearErrors();

        // Validate
        let hasError = false;

        if (!validateEmail(email)) {
            showFieldError('email', 'Please enter a valid email');
            hasError = true;
        }

        if (!password) {
            showFieldError('password', 'Password is required');
            hasError = true;
        }

        if (hasError) return;

        // Try login
        const result = loginUser(email, password);

        if (result.success) {
            window.location.href = 'home.html';
        } else {
            showFieldError('email', result.message);
        }
    });
}

// Setup register form
function setupRegisterForm() {
    const form = document.getElementById('register-form');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm-password').value;

        // Clear previous errors
        clearErrors();

        // Validate
        let hasError = false;

        if (!validateName(name)) {
            showFieldError('name', 'Name must be at least 2 characters');
            hasError = true;
        }

        if (!validateEmail(email)) {
            showFieldError('email', 'Please enter a valid email');
            hasError = true;
        }

        if (!validatePassword(password)) {
            showFieldError('password', 'Password must be at least 6 characters');
            hasError = true;
        }

        if (password !== confirmPassword) {
            showFieldError('confirm-password', 'Passwords do not match');
            hasError = true;
        }

        if (hasError) return;

        // Try register
        const result = registerUser(name, email, password);

        if (result.success) {
            // Auto login
            loginUser(email, password);
            window.location.href = 'home.html';
        } else {
            showFieldError('email', result.message);
        }
    });
}

// Show field error
function showFieldError(fieldId, message) {
    const input = document.getElementById(fieldId);
    if (input) {
        input.classList.add('error');
        const errorEl = input.nextElementSibling;
        if (errorEl && errorEl.classList.contains('form-error')) {
            errorEl.textContent = message;
            errorEl.style.display = 'block';
        }
    }
}

// Clear all errors
function clearErrors() {
    document.querySelectorAll('.form-input.error').forEach(el => {
        el.classList.remove('error');
    });
    document.querySelectorAll('.form-error').forEach(el => {
        el.style.display = 'none';
    });
}

// Initialize auth forms
document.addEventListener('DOMContentLoaded', function () {
    // Redirect if already logged in
    if (isLoggedIn() && (window.location.pathname.endsWith('index.html') ||
        window.location.pathname.endsWith('register.html') ||
        window.location.pathname === '/')) {
        window.location.href = 'home.html';
        return;
    }

    setupLoginForm();
    setupRegisterForm();
});

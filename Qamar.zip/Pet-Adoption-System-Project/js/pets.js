// Pet data and functionality

const pets = [
    {
        id: 1,
        name: 'Buddy',
        type: 'Dog',
        breed: 'Golden Retriever',
        age: '2 years',
        gender: 'Male',
        description: 'Friendly and energetic Golden Retriever who loves playing fetch and swimming. Great with kids and other pets.',
        image: 'https://images.unsplash.com/photo-1552053831-71594a27632d?w=400&h=300&fit=crop'
    },
    {
        id: 2,
        name: 'Luna',
        type: 'Cat',
        breed: 'Persian',
        age: '1 year',
        gender: 'Female',
        description: 'Beautiful Persian cat with silky fur. Calm, affectionate, and loves lounging in sunny spots.',
        image: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400&h=300&fit=crop'
    },
    {
        id: 3,
        name: 'Max',
        type: 'Dog',
        breed: 'German Shepherd',
        age: '3 years',
        gender: 'Male',
        description: 'Intelligent and loyal German Shepherd. Well-trained, protective, and excellent companion for active families.',
        image: 'https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?w=400&h=300&fit=crop'
    },
    {
        id: 4,
        name: 'Bella',
        type: 'Cat',
        breed: 'Maine Coon',
        age: '2 years',
        gender: 'Female',
        description: 'Majestic Maine Coon with a playful personality. Loves interactive toys and following her humans around.',
        image: 'https://images.unsplash.com/photo-1615789591457-74a63395c990?w=400&h=300&fit=crop'
    },
    {
        id: 5,
        name: 'Charlie',
        type: 'Dog',
        breed: 'Beagle',
        age: '1 year',
        gender: 'Male',
        description: 'Curious and merry Beagle puppy. Loves sniffing adventures and makes friends with everyone he meets.',
        image: 'https://images.unsplash.com/photo-1505628346881-b72b27e84530?w=400&h=300&fit=crop'
    },
    {
        id: 6,
        name: 'Coco',
        type: 'Rabbit',
        breed: 'Holland Lop',
        age: '6 months',
        gender: 'Female',
        description: 'Adorable Holland Lop bunny with floppy ears. Gentle, curious, and loves fresh vegetables and cuddles.',
        image: 'https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?w=400&h=300&fit=crop'
    },
    {
        id: 7,
        name: 'Milo',
        type: 'Cat',
        breed: 'Siamese',
        age: '4 years',
        gender: 'Male',
        description: 'Vocal and social Siamese cat. Very affectionate, loves conversation, and will greet you at the door.',
        image: 'https://images.unsplash.com/photo-1568152950566-c1bf43f4ab28?w=400&h=300&fit=crop'
    },
    {
        id: 8,
        name: 'Rocky',
        type: 'Dog',
        breed: 'Bulldog',
        age: '5 years',
        gender: 'Male',
        description: 'Gentle and dignified Bulldog. Perfect couch companion who loves short walks and lots of snuggles.',
        image: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=400&h=300&fit=crop'
    }
];

let currentFilter = 'All';
let searchQuery = '';

// Render pet cards
function renderPets() {
    const grid = document.getElementById('pet-grid');
    if (!grid) return;

    let filteredPets = pets;

    // Apply filter
    if (currentFilter !== 'All') {
        filteredPets = filteredPets.filter(pet => pet.type === currentFilter);
    }

    // Apply search
    if (searchQuery) {
        const query = searchQuery.toLowerCase();
        filteredPets = filteredPets.filter(pet =>
            pet.name.toLowerCase().includes(query) ||
            pet.breed.toLowerCase().includes(query) ||
            pet.type.toLowerCase().includes(query)
        );
    }

    grid.innerHTML = filteredPets.map(pet => `
        <div class="pet-card" data-id="${pet.id}">
            <div class="pet-image-container">
                <img src="${pet.image}" alt="${pet.name}" class="pet-image" loading="lazy">
                <span class="pet-badge">${pet.type}</span>
            </div>
            <div class="pet-info">
                <h3 class="pet-name">${pet.name}</h3>
                <p class="pet-breed">${pet.breed}</p>
                <div class="pet-details">
                    <span class="pet-detail">
                        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10"/>
                            <path d="M12 6v6l4 2"/>
                        </svg>
                        ${pet.age}
                    </span>
                    <span class="pet-detail">
                        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                            <circle cx="12" cy="7" r="4"/>
                        </svg>
                        ${pet.gender}
                    </span>
                </div>
                <p class="pet-description">${pet.description}</p>
                <button class="btn-adopt" onclick="openAdoptModal(${pet.id})">
                    ❤️ Adopt ${pet.name}
                </button>
            </div>
        </div>
    `).join('');

    if (filteredPets.length === 0) {
        grid.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 4rem 2rem; color: var(--text-secondary);">
                <p style="font-size: 1.25rem; margin-bottom: 1rem;">No pets found</p>
                <p>Try adjusting your search or filter</p>
            </div>
        `;
    }
}

// Open adoption modal
function openAdoptModal(petId) {
    const pet = pets.find(p => p.id === petId);
    if (!pet) return;

    const modal = document.getElementById('adopt-modal');
    const overlay = document.getElementById('modal-overlay');

    // Update modal content
    document.getElementById('modal-pet-image').src = pet.image;
    document.getElementById('modal-pet-name').textContent = pet.name;
    document.getElementById('modal-pet-breed').textContent = `${pet.breed} • ${pet.age}`;
    document.getElementById('adopt-pet-id').value = petId;

    // Reset form
    document.getElementById('adoption-form').reset();
    document.getElementById('form-section').style.display = 'block';
    document.getElementById('success-section').style.display = 'none';

    overlay.classList.add('active');
}

// Close modal
function closeAdoptModal() {
    const overlay = document.getElementById('modal-overlay');
    overlay.classList.remove('active');
}

// Submit adoption form
function submitAdoptionForm(e) {
    e.preventDefault();

    const petId = document.getElementById('adopt-pet-id').value;
    const pet = pets.find(p => p.id === parseInt(petId));

    const formData = {
        petId: petId,
        petName: pet?.name,
        adopterName: document.getElementById('adopter-name').value,
        email: document.getElementById('adopter-email').value,
        phone: document.getElementById('adopter-phone').value,
        address: document.getElementById('adopter-address').value,
        experience: document.getElementById('adopter-experience').value,
        submittedAt: new Date().toISOString()
    };

    // Save to localStorage
    const adoptions = JSON.parse(localStorage.getItem('adoptionRequests') || '[]');
    adoptions.push(formData);
    localStorage.setItem('adoptionRequests', JSON.stringify(adoptions));

    // Show success
    document.getElementById('form-section').style.display = 'none';
    document.getElementById('success-section').style.display = 'block';
    document.getElementById('success-pet-name').textContent = pet?.name || 'your new friend';
}

// Filter handling
function setupFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function () {
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            currentFilter = this.dataset.filter;
            renderPets();
        });
    });
}

// Search handling
function setupSearch() {
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('input', function (e) {
            searchQuery = e.target.value;
            renderPets();
        });
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', function () {
    renderPets();
    setupFilters();
    setupSearch();

    // Close modal on overlay click
    const overlay = document.getElementById('modal-overlay');
    if (overlay) {
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) {
                closeAdoptModal();
            }
        });
    }

    // Adoption form submit
    const adoptionForm = document.getElementById('adoption-form');
    if (adoptionForm) {
        adoptionForm.addEventListener('submit', submitAdoptionForm);
    }
});

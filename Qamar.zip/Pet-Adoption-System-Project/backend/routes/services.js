const express = require('express');
const { pool } = require('../config/database');

const router = express.Router();

// Get all services
router.get('/', async (req, res) => {
    try {
        const { active } = req.query;
        let query = 'SELECT * FROM services';
        const params = [];

        if (active !== undefined) {
            query += ' WHERE active = ?';
            params.push(active === 'true');
        } else {
            // Default to active services only
            query += ' WHERE active = TRUE';
        }

        query += ' ORDER BY id';

        const [services] = await pool.query(query, params);
        res.json(services);
    } catch (error) {
        console.error('Get services error:', error);
        res.status(500).json({ error: 'Failed to get services' });
    }
});

// Get single service
router.get('/:id', async (req, res) => {
    try {
        const [services] = await pool.query(
            'SELECT * FROM services WHERE id = ?',
            [req.params.id]
        );

        if (services.length === 0) {
            return res.status(404).json({ error: 'Service not found' });
        }

        res.json(services[0]);
    } catch (error) {
        console.error('Get service error:', error);
        res.status(500).json({ error: 'Failed to get service' });
    }
});

module.exports = router;

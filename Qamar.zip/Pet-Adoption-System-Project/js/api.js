// API Configuration
const API_BASE_URL = 'http://localhost:3000/api';

// API Helper functions
const api = {
    // Auth endpoints
    auth: {
        async register(data) {
            const res = await fetch(`${API_BASE_URL}/auth/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            return res.json();
        },

        async login(email, password) {
            const res = await fetch(`${API_BASE_URL}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            return res.json();
        },

        async getProfile(userId) {
            const res = await fetch(`${API_BASE_URL}/auth/profile/${userId}`);
            return res.json();
        }
    },

    // Pets endpoints
    pets: {
        async getAll(filters = {}) {
            const params = new URLSearchParams(filters);
            const res = await fetch(`${API_BASE_URL}/pets?${params}`);
            return res.json();
        },

        async getById(id) {
            const res = await fetch(`${API_BASE_URL}/pets/${id}`);
            return res.json();
        }
    },

    // Services endpoints
    services: {
        async getAll() {
            const res = await fetch(`${API_BASE_URL}/services`);
            return res.json();
        },

        async getById(id) {
            const res = await fetch(`${API_BASE_URL}/services/${id}`);
            return res.json();
        }
    },

    // Adoptions endpoints
    adoptions: {
        async submit(data) {
            const res = await fetch(`${API_BASE_URL}/adoptions`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            return res.json();
        },

        async getByUser(userId) {
            const res = await fetch(`${API_BASE_URL}/adoptions?user_id=${userId}`);
            return res.json();
        }
    },

    // Appointments endpoints
    appointments: {
        async book(data) {
            const res = await fetch(`${API_BASE_URL}/appointments`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            return res.json();
        },

        async getByUser(userId) {
            const res = await fetch(`${API_BASE_URL}/appointments?user_id=${userId}`);
            return res.json();
        },

        async cancel(id) {
            const res = await fetch(`${API_BASE_URL}/appointments/${id}`, {
                method: 'DELETE'
            });
            return res.json();
        }
    },

    // Health check
    async healthCheck() {
        try {
            const res = await fetch(`${API_BASE_URL}/health`);
            return res.json();
        } catch (error) {
            return { status: 'error', database: 'disconnected' };
        }
    }
};

// Check if API is available
async function checkApiConnection() {
    const health = await api.healthCheck();
    if (health.database === 'connected') {
        console.log('✅ API connected to database');
        return true;
    } else {
        console.log('⚠️ API not connected - using local storage fallback');
        return false;
    }
}

# Pet Adoption System 🐾

A modern pet adoption website with TiDB Cloud database integration.

## Prerequisites

- **Node.js** (v18 or higher) - [Download](https://nodejs.org/)
- **MySQL Client** (optional, for database setup)

---

## Quick Start

### Step 1: Install Backend Dependencies

```bash
cd backend
npm install
```

### Step 2: Configure Database

Create a `.env` file in the `backend/` folder:

```env
TIDB_HOST=gateway01.us-east-1.prod.aws.tidbcloud.com
TIDB_PORT=4000
TIDB_USER=ehhY4YiwHZnsfu4.root
TIDB_PASSWORD=Qqy0z86isevhjesv
TIDB_DATABASE=pet_adoption
PORT=3000
```

> **Note:** The database is already set up in TiDB Cloud with sample data.

### Step 3: Start the Backend Server

```bash
cd backend
npm start
```

You should see:
```
🚀 Server running on http://localhost:3000
✅ Connected to TiDB Cloud successfully!
```

### Step 4: Open the Website

Open `index.html` in your browser (just double-click it).

---

## Features

- 🔐 User Registration & Login
- 🐕 Browse 8 pets (dogs, cats, rabbit)
- 🔍 Filter by type & search
- 📝 Submit adoption requests
- 📅 Book pet care appointments
- 💉 6 pet care services

---

## API Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/pets` | Get all pets |
| `POST /api/auth/register` | Register user |
| `POST /api/auth/login` | Login |
| `POST /api/adoptions` | Submit adoption |
| `POST /api/appointments` | Book appointment |
| `GET /api/services` | Get services |

---

## Project Structure

```
Pet-Adoption-System-Project/
├── index.html          # Login page
├── register.html       # Registration
├── home.html           # Pet list
├── treatment.html      # Pet care services
├── booking.html        # Book appointment
├── css/styles.css      # Styling
├── js/                 # Frontend scripts
├── database/schema.sql # Database schema
└── backend/            # Node.js API
```

---

## Troubleshooting

**Backend won't start?**
- Make sure you have Node.js installed: `node --version`
- Make sure `.env` file exists in `backend/` folder

**Can't connect to database?**
- Check your internet connection
- Verify the TiDB credentials are correct

---

Made with ❤️ for pets and their future families

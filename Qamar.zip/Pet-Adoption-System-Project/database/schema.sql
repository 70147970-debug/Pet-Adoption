-- ============================================
-- Pet Adoption System - TiDB Cloud Schema
-- ============================================
-- Compatible with TiDB Cloud (MySQL compatible)
-- Run this script to create all tables
-- ============================================

-- Create database (if not exists)
CREATE DATABASE IF NOT EXISTS pet_adoption;
USE pet_adoption;

-- ============================================
-- 1. USERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_users_email (email)
);

-- ============================================
-- 2. PETS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS pets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    type VARCHAR(20) NOT NULL COMMENT 'dog, cat, rabbit, etc.',
    breed VARCHAR(50) NOT NULL,
    age VARCHAR(20) NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    description TEXT,
    image_url VARCHAR(500),
    status ENUM('available', 'pending', 'adopted') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_pets_type (type),
    INDEX idx_pets_status (status)
);

-- ============================================
-- 3. SERVICES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS services (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(10) COMMENT 'Emoji icon',
    price_min DECIMAL(10,2) NOT NULL,
    price_max DECIMAL(10,2) COMMENT 'NULL for fixed price',
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- 4. ADOPTIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS adoptions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    pet_id INT NOT NULL,
    adopter_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address VARCHAR(255) NOT NULL,
    message TEXT,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE CASCADE,
    INDEX idx_adoptions_pet (pet_id),
    INDEX idx_adoptions_status (status)
);

-- ============================================
-- 5. APPOINTMENTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS appointments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    service_id INT NOT NULL,
    owner_name VARCHAR(100) NOT NULL,
    owner_email VARCHAR(255) NOT NULL,
    owner_phone VARCHAR(20) NOT NULL,
    owner_address VARCHAR(255),
    pet_name VARCHAR(50) NOT NULL,
    pet_type VARCHAR(20) NOT NULL,
    pet_breed VARCHAR(50),
    pet_age VARCHAR(20),
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    notes TEXT,
    status ENUM('scheduled', 'completed', 'cancelled') DEFAULT 'scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
    INDEX idx_appointments_date (appointment_date),
    INDEX idx_appointments_service (service_id)
);

-- ============================================
-- SEED DATA: Services
-- ============================================
INSERT INTO services (name, description, icon, price_min, price_max) VALUES
('Nutrition & Diet', 'Get personalized diet plans and nutrition advice from our pet nutrition experts.', '🍖', 45.00, NULL),
('Vaccinations', 'Keep your pet protected with our comprehensive vaccination services.', '💉', 35.00, 75.00),
('Grooming & Spa', 'Professional grooming services to keep your pet looking and feeling great.', '🛁', 50.00, 120.00),
('Pet Training', 'Expert training sessions to help your pet learn commands and good behavior.', '🏃', 60.00, NULL),
('Health Check-ups', 'Comprehensive wellness exams to ensure your pet stays healthy.', '🩺', 55.00, 150.00),
('Parasite Treatment', 'Protect your pet from fleas, ticks, and worms with our prevention services.', '🛡️', 25.00, 65.00);

-- ============================================
-- SEED DATA: Sample Pets
-- ============================================
INSERT INTO pets (name, type, breed, age, gender, description, image_url, status) VALUES
('Buddy', 'Dog', 'Golden Retriever', '2 years', 'Male', 'Friendly and energetic Golden Retriever who loves playing fetch and swimming. Great with kids and other pets.', 'https://images.unsplash.com/photo-1552053831-71594a27632d?w=400', 'available'),
('Luna', 'Cat', 'Persian', '1 year', 'Female', 'Beautiful Persian cat with silky fur. Calm, affectionate, and loves lounging in sunny spots.', 'https://images.unsplash.com/photo-1574158622682-e40e69881006?w=400', 'available'),
('Max', 'Dog', 'German Shepherd', '3 years', 'Male', 'Intelligent and loyal German Shepherd. Well-trained, protective, and excellent companion for active families.', 'https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?w=400', 'available'),
('Bella', 'Cat', 'Maine Coon', '2 years', 'Female', 'Majestic Maine Coon with a playful personality. Loves interactive toys and following her humans around.', 'https://images.unsplash.com/photo-1533738363-b7f9aef128ce?w=400', 'available'),
('Charlie', 'Dog', 'Beagle', '1 year', 'Male', 'Curious and merry Beagle puppy. Loves exploring outdoors and has an excellent nose for adventure.', 'https://images.unsplash.com/photo-1505628346881-b72b27e84530?w=400', 'available'),
('Coco', 'Rabbit', 'Holland Lop', '8 months', 'Female', 'Adorable Holland Lop bunny with floppy ears. Gentle, loves cuddles, and enjoys hopping around.', 'https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?w=400', 'available'),
('Milo', 'Cat', 'Siamese', '4 years', 'Male', 'Vocal and affectionate Siamese cat. Loves conversation and being the center of attention.', 'https://images.unsplash.com/photo-1513360371669-4adf3dd7dff8?w=400', 'available'),
('Rocky', 'Dog', 'Bulldog', '5 years', 'Male', 'Gentle and dependable Bulldog. Calm demeanor, loves short walks and long naps on the couch.', 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=400', 'available');

-- ============================================
-- DONE!
-- ============================================
SELECT 'Schema created successfully!' AS status;
SELECT COUNT(*) AS total_services FROM services;
SELECT COUNT(*) AS total_pets FROM pets;

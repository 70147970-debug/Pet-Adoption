const express = require('express');
const { pool } = require('../config/database');

const router = express.Router();

// Book appointment
router.post('/', async (req, res) => {
    try {
        const {
            user_id,
            service_id,
            owner_name,
            owner_email,
            owner_phone,
            owner_address,
            pet_name,
            pet_type,
            pet_breed,
            pet_age,
            appointment_date,
            appointment_time,
            notes
        } = req.body;

        const [result] = await pool.query(
            `INSERT INTO appointments 
            (user_id, service_id, owner_name, owner_email, owner_phone, owner_address, 
             pet_name, pet_type, pet_breed, pet_age, appointment_date, appointment_time, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                user_id || null,
                service_id,
                owner_name,
                owner_email,
                owner_phone,
                owner_address || null,
                pet_name,
                pet_type,
                pet_breed || null,
                pet_age || null,
                appointment_date,
                appointment_time,
                notes || null
            ]
        );

        res.status(201).json({
            message: 'Appointment booked successfully',
            appointmentId: result.insertId
        });
    } catch (error) {
        console.error('Book appointment error:', error);
        res.status(500).json({ error: 'Failed to book appointment' });
    }
});

// Get all appointments
router.get('/', async (req, res) => {
    try {
        const { date, status, user_id, service_id } = req.query;
        let query = `
            SELECT a.*, s.name as service_name, s.icon as service_icon
            FROM appointments a
            JOIN services s ON a.service_id = s.id
            WHERE 1=1
        `;
        const params = [];

        if (date) {
            query += ' AND a.appointment_date = ?';
            params.push(date);
        }

        if (status) {
            query += ' AND a.status = ?';
            params.push(status);
        }

        if (user_id) {
            query += ' AND a.user_id = ?';
            params.push(user_id);
        }

        if (service_id) {
            query += ' AND a.service_id = ?';
            params.push(service_id);
        }

        query += ' ORDER BY a.appointment_date, a.appointment_time';

        const [appointments] = await pool.query(query, params);
        res.json(appointments);
    } catch (error) {
        console.error('Get appointments error:', error);
        res.status(500).json({ error: 'Failed to get appointments' });
    }
});

// Get single appointment
router.get('/:id', async (req, res) => {
    try {
        const [appointments] = await pool.query(
            `SELECT a.*, s.name as service_name, s.icon as service_icon
             FROM appointments a
             JOIN services s ON a.service_id = s.id
             WHERE a.id = ?`,
            [req.params.id]
        );

        if (appointments.length === 0) {
            return res.status(404).json({ error: 'Appointment not found' });
        }

        res.json(appointments[0]);
    } catch (error) {
        console.error('Get appointment error:', error);
        res.status(500).json({ error: 'Failed to get appointment' });
    }
});

// Update appointment status
router.patch('/:id/status', async (req, res) => {
    try {
        const { status } = req.body;

        await pool.query(
            'UPDATE appointments SET status = ? WHERE id = ?',
            [status, req.params.id]
        );

        res.json({ message: 'Appointment status updated' });
    } catch (error) {
        console.error('Update appointment error:', error);
        res.status(500).json({ error: 'Failed to update appointment' });
    }
});

// Cancel appointment
router.delete('/:id', async (req, res) => {
    try {
        await pool.query(
            'UPDATE appointments SET status = ? WHERE id = ?',
            ['cancelled', req.params.id]
        );

        res.json({ message: 'Appointment cancelled' });
    } catch (error) {
        console.error('Cancel appointment error:', error);
        res.status(500).json({ error: 'Failed to cancel appointment' });
    }
});

module.exports = router;

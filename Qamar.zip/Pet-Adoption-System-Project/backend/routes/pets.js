const express = require('express');
const { pool } = require('../config/database');

const router = express.Router();

// Get all pets (with optional filters)
router.get('/', async (req, res) => {
    try {
        const { type, status, search } = req.query;
        let query = 'SELECT * FROM pets WHERE 1=1';
        const params = [];

        if (type) {
            query += ' AND type = ?';
            params.push(type);
        }

        if (status) {
            query += ' AND status = ?';
            params.push(status);
        } else {
            // Default to available pets
            query += ' AND status = ?';
            params.push('available');
        }

        if (search) {
            query += ' AND (name LIKE ? OR breed LIKE ?)';
            params.push(`%${search}%`, `%${search}%`);
        }

        query += ' ORDER BY created_at DESC';

        const [pets] = await pool.query(query, params);
        res.json(pets);
    } catch (error) {
        console.error('Get pets error:', error);
        res.status(500).json({ error: 'Failed to get pets' });
    }
});

// Get single pet
router.get('/:id', async (req, res) => {
    try {
        const [pets] = await pool.query(
            'SELECT * FROM pets WHERE id = ?',
            [req.params.id]
        );

        if (pets.length === 0) {
            return res.status(404).json({ error: 'Pet not found' });
        }

        res.json(pets[0]);
    } catch (error) {
        console.error('Get pet error:', error);
        res.status(500).json({ error: 'Failed to get pet' });
    }
});

// Add new pet (admin)
router.post('/', async (req, res) => {
    try {
        const { name, type, breed, age, gender, description, image_url } = req.body;

        const [result] = await pool.query(
            'INSERT INTO pets (name, type, breed, age, gender, description, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [name, type, breed, age, gender, description, image_url]
        );

        res.status(201).json({
            message: 'Pet added successfully',
            petId: result.insertId
        });
    } catch (error) {
        console.error('Add pet error:', error);
        res.status(500).json({ error: 'Failed to add pet' });
    }
});

// Update pet status
router.patch('/:id/status', async (req, res) => {
    try {
        const { status } = req.body;

        await pool.query(
            'UPDATE pets SET status = ? WHERE id = ?',
            [status, req.params.id]
        );

        res.json({ message: 'Pet status updated' });
    } catch (error) {
        console.error('Update pet error:', error);
        res.status(500).json({ error: 'Failed to update pet' });
    }
});

module.exports = router;

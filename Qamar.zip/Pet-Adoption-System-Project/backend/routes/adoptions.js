const express = require('express');
const { pool } = require('../config/database');

const router = express.Router();

// Submit adoption request
router.post('/', async (req, res) => {
    try {
        const { user_id, pet_id, adopter_name, phone, address, message } = req.body;

        // Check if pet is available
        const [pets] = await pool.query(
            'SELECT status FROM pets WHERE id = ?',
            [pet_id]
        );

        if (pets.length === 0) {
            return res.status(404).json({ error: 'Pet not found' });
        }

        if (pets[0].status !== 'available') {
            return res.status(400).json({ error: 'Pet is not available for adoption' });
        }

        // Create adoption request
        const [result] = await pool.query(
            'INSERT INTO adoptions (user_id, pet_id, adopter_name, phone, address, message) VALUES (?, ?, ?, ?, ?, ?)',
            [user_id || null, pet_id, adopter_name, phone, address, message || null]
        );

        // Update pet status to pending
        await pool.query(
            'UPDATE pets SET status = ? WHERE id = ?',
            ['pending', pet_id]
        );

        res.status(201).json({
            message: 'Adoption request submitted successfully',
            adoptionId: result.insertId
        });
    } catch (error) {
        console.error('Adoption error:', error);
        res.status(500).json({ error: 'Failed to submit adoption request' });
    }
});

// Get all adoption requests
router.get('/', async (req, res) => {
    try {
        const { status, user_id } = req.query;
        let query = `
            SELECT a.*, p.name as pet_name, p.type as pet_type, p.breed as pet_breed, p.image_url
            FROM adoptions a
            JOIN pets p ON a.pet_id = p.id
            WHERE 1=1
        `;
        const params = [];

        if (status) {
            query += ' AND a.status = ?';
            params.push(status);
        }

        if (user_id) {
            query += ' AND a.user_id = ?';
            params.push(user_id);
        }

        query += ' ORDER BY a.created_at DESC';

        const [adoptions] = await pool.query(query, params);
        res.json(adoptions);
    } catch (error) {
        console.error('Get adoptions error:', error);
        res.status(500).json({ error: 'Failed to get adoptions' });
    }
});

// Update adoption status
router.patch('/:id/status', async (req, res) => {
    try {
        const { status } = req.body;
        const adoptionId = req.params.id;

        // Get adoption to find pet
        const [adoptions] = await pool.query(
            'SELECT pet_id FROM adoptions WHERE id = ?',
            [adoptionId]
        );

        if (adoptions.length === 0) {
            return res.status(404).json({ error: 'Adoption request not found' });
        }

        // Update adoption status
        await pool.query(
            'UPDATE adoptions SET status = ? WHERE id = ?',
            [status, adoptionId]
        );

        // Update pet status based on adoption status
        const petStatus = status === 'approved' ? 'adopted' : 'available';
        await pool.query(
            'UPDATE pets SET status = ? WHERE id = ?',
            [petStatus, adoptions[0].pet_id]
        );

        res.json({ message: 'Adoption status updated' });
    } catch (error) {
        console.error('Update adoption error:', error);
        res.status(500).json({ error: 'Failed to update adoption' });
    }
});

module.exports = router;
